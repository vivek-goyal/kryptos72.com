<?php
/*
 *  Plugin Name:  Air Addons
 *  Plugin URI:   http://air.redbrush.eu
 *  Author:       Redbrush
 *  Author URI:   http://redbrush.eu
 *  Description:  Premium addons for Visual Composer
 *  Version:      1.0.0
 *  Text Domain:  air_addons
 *  Domain Path:  /languages/
 */

// don't load directly
if (!defined('ABSPATH')) die('-1');

// require_once 'classes/AirAddons.php';
require_once 'classes/AirProjects.php';
